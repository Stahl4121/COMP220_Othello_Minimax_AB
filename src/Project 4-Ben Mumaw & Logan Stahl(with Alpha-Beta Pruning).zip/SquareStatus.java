/**
 * Enum that keeps track of the 3 possible square statuses on the othello board.
 * @author MUMAWBM1
 *
 */
public enum SquareStatus {
	BLACK, WHITE, EMPTY
}
